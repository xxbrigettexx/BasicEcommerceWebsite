<?php
session_start();
require 'db.php'; 
?>


<!DOCTYPE html>
<html>
	<head><title>Log In</title>
		<link rel="stylesheet" type="text/css" href="./style/css/bootstrap.min.css">
		<link rel="stylesheet" href="css.css" type="text/css">
		<div class="body-content">
	</head>
	
	<?php 
if ($_SERVER['REQUEST_METHOD'] == 'POST') 
{
    if (isset($_POST['login'])) {

        require 'login.php';
        
    }
}
?>
  
	<body>
	<div class="module">
		<h1>Log In</h1>
		<form class="form" action="products.php" method="post" enctype="multipart/form-data" autocomplete="off">
			<input type="email" placeholder="Email" name="email" required />
			<input type="password" placeholder="Password" name="pword" autocomplete="new-pword" required />
			<input type="submit" value="Login" name="register" class="btn btn-block btn-primary" />
		</form>
		</div>
	
	</body>
</html>
		