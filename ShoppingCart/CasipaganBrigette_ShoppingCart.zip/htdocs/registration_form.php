<?php
session_start();
require 'db.php';
require 'validate.php';

?>



<!DOCTYPE html>
<html>
	<head><title>Register</title>
		<link rel="stylesheet" type="text/css" href="./style/css/bootstrap.min.css">
		<link rel="stylesheet" href="css.css" type="text/css">
		<div class="body-content">
	</head>
	
	<body>
	<div class="module">
		<h1>Register</h1>
		<form class="form" action="registration_form.php" method="post" enctype="multipart/form-data" autocomplete="off">
			<div class="alert alert-error"><?= $_SESSION['message']?></div>
			<input type="text" placeholder="First Name" name="firstname" required />
			<input type="text" placeholder="Last Name" name="lastname" required />
			<input type="email" placeholder="Email" name="email" required />
			<input type="password" placeholder="Password" name="pword" autocomplete="new-pword" required />
			<input type="password" placeholder="Confirm Password" name="confirmpassword" autocomplete="new-pword" required />
			<input type="submit" value="Register" name="register" class="btn btn-block btn-primary" />
			
		</form>
		</div>
	<h3>Already have an account?</h3>
	<a href="loginPage.php">LOG IN</a>
	</body>
</html>
		