<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
  <title>Error</title>
  <link rel="stylesheet" type="text/css" href="./style/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="form.css" type="text/css">
		<div class="body-content">
</head>
<body>
<div class="module">
    <h1>Error</h1>
    <p>
    <?php 
    if( isset($_SESSION['message']) AND !empty($_SESSION['message']) ): 
        echo $_SESSION['message'];
    endif;
    ?>
    </p>     
    <a href="loginPage.php"><button class="btn btn-block btn-primary"/>Back</button></a>
</div>
</body>
</html>
