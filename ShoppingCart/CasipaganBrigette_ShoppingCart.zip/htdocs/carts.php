<?php
require 'db.php';

if(isset($_POST["add_to_cart"]))
	{
		if(isset($_SESSION["products"]))
		{
			$item_array_id = array_column($_SESSION["products"], "item_id");
			if(!in_array($_GET["id"], $item_array_id))
			{
				$count = count($_SESSION["products"]);
				$item_array = array('item_id' => $_GET["id"], 
									'item_name' => $_POST["hidden_name"], 
									'item_price' => $_POST["hidden_price"], 
									'item_quantity' => $_POST["quantity"]);
				$_SESSION["products"][$count] = $item_array;
				
			/**$item_id = intval($_GET['id']);
					$item_name = $mysqli->real_escape_string($_POST['hidden_name']);
					$item_price = intval($_POST['hidden_price']);
					$item_quantity = intval($_POST['quantity']);
					
					$sql = "INSERT INTO cart_items(item_name, item_quantity, item_price)"
					. "VALUES('$item_name', '$item_quantity', '$item_price)";
					
					if($mysqli->query($sql) === true){
						$_SESSION['added'] = true;
						$_SESSION['message'] = "You added item/s into the cart!";
						header("location:cart_items.php");
					}else{
					$_SESSION['message'] = 'Item/s could not be added.';
					}
					$mysqli->close(); */
			}
		}
		else
		{
			$item_array = array('item_id' => $_GET["id"], 
						'item_name' => $_POST["hidden_name"], 
						'item_price' => $_POST["hidden_price"],
						'item_quantity' => $_POST["quantity"]);
			$_SESSION["products"][0] = $item_array;
					
		}	
	}
	if(isset($_GET["action"]))
	{
		if($_GET["action"] == "delete")
		{
			foreach($_SESSION["products"] as $keys => $values)
			{
			if($values["item_id"] == $_GET["id"])
			{
				unset($_SESSION["products"][$keys]);
				echo '<script>alert("Item Removed")</script>';
				echo '<script>window.location="cart_items.php"</script>';
			}
			}
		}
}
	
?>