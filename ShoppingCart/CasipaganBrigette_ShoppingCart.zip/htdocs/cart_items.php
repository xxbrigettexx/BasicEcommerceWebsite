<?php
session_start();
require 'db.php';
require 'carts.php';
?>

<!DOCTYPE html>
<head>
	<title>Cart Items</title>
	
	<link rel="stylesheet" type="text/css" href="./style/css/bootstrap.min.css">
	<link rel="stylesheet" href="css.css" type="text/css">
</head>

<body>

<div style="clear:both"></div>
		<br />
		<h3>Cart</h3>
		<div class="table-responsive">
		<table>
		<tr>
		<th>Item Name</th>
		<th>Quantity</th>
		<th>Price</th>
		<th>Total</th>
		<th>Action</th>
		</tr>
		<?php
		if(!empty($_SESSION["products"]))
		{
			$total = 0;
			foreach($_SESSION["products"] as $keys => $values)
			{
				?>
				<tr>
				<td><?php echo $values["item_name"]; ?></td>
				<td><?php echo $values["item_quantity"]; ?></td>
				<td>$ <?php echo $values["item_price"]; ?></td>
				<td>$ <?php echo number_format($values["item_quantity"] * $values["item_price"], 2); ?></td>
				<td><a href="cart_items.php?action=delete&id=<?php echo $values["item_id"];?>">
				<span class="text-danger">Remove</span></a></td>
				</tr>
				<?php
				$total = $total + ($values["item_quantity"] * $values["item_price"]);
			}
			?>
			<tr>
			<td colspan="3" align="right">Total</td>
			<td align="right">$<?php echo number_format($total, 2); ?></td>
			<td></td>
			</tr>
		<?php
		}
		?>
		
		</table>
		<a href="products.php" class="back">Back to Products</a>
		
			<form class="paypal" action="payments.php" method="post" id="paypal_form" target="_blank">
			<input type="hidden" name="cmd" value="_xclick" />
			<input type="hidden" name="no_note" value="1" />
			<input type="hidden" name="lc" value="PHP" />
			<input type="hidden" name="currency_code" value="GBP" />
			<input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
			<input type="hidden" name="firstname" value="firstname"  />
			<input type="hidden" name="lastname" value="lastname"  />
			<input type="hidden" name="payeremail" value="email"  />
			<input type="hidden" name="item_id" value="item_id" / >
			<input type="submit" name="submit" style="margin-top:5px;" class="back" value="Submit Payment"/>
			</form>
		</div>
		</div>
		<br />
</body>
</html>