<?php
$_SESSION['message']='';

$mysqli= new mysqli('localhost', 'root', '', 'gette');
if($mysqli->connect_errno){
	printf("Connection failed: %s \n", $mysqli->connect_errno);
	die();
}

?>