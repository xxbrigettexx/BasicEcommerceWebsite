<?php

if($_SERVER["REQUEST_METHOD"] == "POST"){
	if($_POST['pword'] == $_POST['confirmpassword'])
	{
		$firstname = $mysqli->real_escape_string($_POST['firstname']);
		$lastname = $mysqli->real_escape_string($_POST['lastname']);
		$email = $mysqli->real_escape_string($_POST['email']);
		$pword = md5($_POST['pword']);
		
	$sql = "INSERT INTO customers(first_name, last_name, email, password)"
	. "VALUES('$firstname', '$lastname', '$email', '$pword')";

		if($mysqli->query($sql) === true){
			$_SESSION['active'] = 0;
			$_SESSION['logged_in'] = true;
			$_SESSION['message'] = "Registration successful!!!!!! 
			. Added $firstname to the database!!!!";
			header("location:products.php");
		}
	else{
		$_SESSION['message'] = 'User could not be added to the database';
	}
	$mysqli->close();
}
else {
	$_SESSION['message'] = 'Two passwords do not match!';
}

}
	
?>

